interface StatCard {
  icon: string;
  label: string;
  value: number | string;
  trend?: { value: number; direction: 'up' | 'down' };
  color?: 'primary' | 'success' | 'warning' | 'error';
}

interface DashboardStatsProps {
  stats: StatCard[];
}

export function DashboardStats({ stats }: DashboardStatsProps) {
  const colorMap = {
    primary: 'bg-blue-50 text-blue-700',
    success: 'bg-green-50 text-green-700',
    warning: 'bg-amber-50 text-amber-700',
    error: 'bg-red-50 text-red-700',
  };

  return (
    <div className="dashboard-grid">
      {stats.map((stat, idx) => (
        <div key={idx} className="stat-panel">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">{stat.label}</p>
              <h2 className="text-3xl font-bold text-gray-900">{stat.value}</h2>
              {stat.trend && (
                <p className={`text-xs font-medium mt-2 ${
                  stat.trend.direction === 'up' 
                    ? 'text-green-600' 
                    : 'text-red-600'
                }`}>
                  {stat.trend.direction === 'up' ? '↑' : '↓'} {stat.trend.value}%
                </p>
              )}
            </div>
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-lg ${
              colorMap[stat.color || 'primary']
            }`}>
              {stat.icon}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
