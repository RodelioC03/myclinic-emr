import React from 'react';

interface FormSectionProps {
  title: string;
  subtitle?: string;
  icon?: string;
  children: React.ReactNode;
  className?: string;
  collapsible?: boolean;
}

export function FormSection({
  title,
  subtitle,
  icon,
  children,
  className = '',
  collapsible = false,
}: FormSectionProps) {
  const [isExpanded, setIsExpanded] = React.useState(true);

  return (
    <div className={`history-section ${className}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {icon && <span className="text-lg">{icon}</span>}
          <div>
            <h3 className="text-sm font-semibold text-gray-900">{title}</h3>
            {subtitle && <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>}
          </div>
        </div>
        {collapsible && (
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            {isExpanded ? '−' : '+'}
          </button>
        )}
      </div>
      {isExpanded && <div className="mt-3">{children}</div>}
    </div>
  );
}
