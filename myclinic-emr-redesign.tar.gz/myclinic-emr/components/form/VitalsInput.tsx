import { Vitals } from "@/app/page";

interface VitalsInputProps {
  vitals: Vitals;
  onChange: (key: keyof Vitals, value: string) => void;
}

const vitalsConfig = [
  { key: 'bp' as const, label: 'BP', unit: 'mmHg', placeholder: '120/80' },
  { key: 'hr' as const, label: 'HR', unit: 'bpm', placeholder: '72' },
  { key: 'rr' as const, label: 'RR', unit: 'bpm', placeholder: '16' },
  { key: 'temp' as const, label: 'Temp', unit: '°C', placeholder: '36.5' },
  { key: 'spo2' as const, label: 'SpO2', unit: '%', placeholder: '98' },
  { key: 'weight' as const, label: 'Weight', unit: 'kg', placeholder: '70' },
];

export function VitalsInput({ vitals, onChange }: VitalsInputProps) {
  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
      <h3 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
        <span className="text-lg">📊</span> Vital Signs
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {vitalsConfig.map(({ key, label, unit, placeholder }) => (
          <div key={key} className="flex flex-col">
            <label className="text-xs font-medium text-gray-600 mb-1.5">
              {label}
              <span className="text-gray-400 ml-1">({unit})</span>
            </label>
            <input
              type="text"
              placeholder={placeholder}
              value={vitals[key]}
              onChange={(e) => onChange(key, e.target.value)}
              className="w-full px-2.5 py-1.5 text-sm border border-blue-200 rounded-md bg-white focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
