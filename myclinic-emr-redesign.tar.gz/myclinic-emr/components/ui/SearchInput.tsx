import React from 'react';

interface SearchInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  onClear?: () => void;
  hasValue?: boolean;
}

export function SearchInput({
  icon = '🔍',
  onClear,
  hasValue = false,
  className = '',
  ...props
}: SearchInputProps) {
  return (
    <div className="relative w-full">
      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
        {icon}
      </div>
      <input
        className={`
          search-box
          w-full pl-10 pr-10
          ${className}
        `}
        {...props}
      />
      {hasValue && onClear && (
        <button
          type="button"
          onClick={onClear}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-lg"
        >
          ✕
        </button>
      )}
    </div>
  );
}
