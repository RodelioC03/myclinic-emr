import React, { useState } from 'react';

export interface TabItem {
  id: string;
  label: string;
  icon?: string;
  content: React.ReactNode;
}

interface TabsProps {
  tabs: TabItem[];
  defaultTab?: string;
  onChange?: (tabId: string) => void;
  variant?: 'default' | 'pills';
}

export function Tabs({
  tabs,
  defaultTab,
  onChange,
  variant = 'default',
}: TabsProps) {
  const [activeTab, setActiveTab] = useState(defaultTab || tabs[0]?.id);

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    onChange?.(tabId);
  };

  const activeTabContent = tabs.find((tab) => tab.id === activeTab)?.content;

  const tabButtonStyles =
    variant === 'pills'
      ? 'px-4 py-2 rounded-lg hover:bg-gray-100'
      : 'px-4 py-3 border-b-2 border-transparent hover:border-gray-300';

  return (
    <div>
      <div className="flex gap-1 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`
              tab-header
              ${tabButtonStyles}
              ${
                activeTab === tab.id
                  ? 'text-blue-600 border-blue-600 font-semibold'
                  : 'text-gray-600 font-medium'
              }
              transition-colors
            `}
          >
            {tab.icon && <span className="mr-1">{tab.icon}</span>}
            {tab.label}
          </button>
        ))}
      </div>
      <div className="mt-4">{activeTabContent}</div>
    </div>
  );
}
