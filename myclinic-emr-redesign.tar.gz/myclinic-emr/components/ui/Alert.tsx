import React from 'react';

interface AlertProps {
  children: React.ReactNode;
  variant?: 'info' | 'success' | 'warning' | 'error';
  icon?: React.ReactNode;
  onClose?: () => void;
  className?: string;
}

export function Alert({
  children,
  variant = 'info',
  icon,
  onClose,
  className = '',
}: AlertProps) {
  const variantStyles = {
    info: 'bg-blue-50 border border-blue-200 text-blue-900',
    success: 'bg-green-50 border border-green-200 text-green-900',
    warning: 'bg-amber-50 border border-amber-200 text-amber-900',
    error: 'bg-red-50 border border-red-200 text-red-900',
  };

  const iconMap = {
    info: 'ℹ️',
    success: '✓',
    warning: '⚠️',
    error: '✕',
  };

  return (
    <div
      className={`
        toast
        ${variantStyles[variant]}
        rounded-lg p-4 mb-4 flex items-start gap-3
        ${className}
      `}
      role="alert"
    >
      <span className="text-lg flex-shrink-0">
        {icon || iconMap[variant]}
      </span>
      <div className="flex-1 text-sm">{children}</div>
      {onClose && (
        <button
          onClick={onClose}
          className="flex-shrink-0 ml-2 text-lg opacity-70 hover:opacity-100"
        >
          ✕
        </button>
      )}
    </div>
  );
}
