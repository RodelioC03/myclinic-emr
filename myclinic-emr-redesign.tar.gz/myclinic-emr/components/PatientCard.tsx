import { Patient } from "@/app/page";

interface PatientCardProps {
  patient: Patient;
  onView: () => void;
  onConsult: () => void;
}

export function PatientCard({ patient, onView, onConsult }: PatientCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const calculateAge = (dob: string) => {
    if (!dob) return "N/A";
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (
      monthDiff < 0 ||
      (monthDiff === 0 && today.getDate() < birthDate.getDate())
    ) {
      age--;
    }
    return age;
  };

  return (
    <div className="panel hover:shadow-lg transition-all">
      <div className="p-4 flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-semibold text-blue-700">
                {getInitials(patient.fullName)}
              </span>
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-gray-900 truncate">
                {patient.fullName}
              </h3>
              <p className="text-xs text-gray-500">ID: {patient.id}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs mb-3">
            <div>
              <p className="text-gray-500">Age</p>
              <p className="font-medium text-gray-900">{calculateAge(patient.dob)}</p>
            </div>
            <div>
              <p className="text-gray-500">Contact</p>
              <p className="font-medium text-gray-900">{patient.contact || "N/A"}</p>
            </div>
            <div>
              <p className="text-gray-500">Last Visit</p>
              <p className="font-medium text-gray-900">
                {patient.lastConsult ? new Date(patient.lastConsult).toLocaleDateString() : "Never"}
              </p>
            </div>
          </div>

          {patient.allergies && (
            <div className="mb-3 pb-3 border-t border-gray-100">
              <p className="text-xs text-gray-500 mb-1">Allergies</p>
              <div className="flex flex-wrap gap-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700">
                  {patient.allergies}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-2 px-4 py-3 border-t border-gray-100">
        <button
          onClick={onView}
          className="flex-1 px-3 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
        >
          View Profile
        </button>
        <button
          onClick={onConsult}
          className="flex-1 px-3 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
        >
          New Consult
        </button>
      </div>
    </div>
  );
}
